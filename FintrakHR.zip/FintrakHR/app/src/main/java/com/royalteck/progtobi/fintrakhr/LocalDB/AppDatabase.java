package com.royalteck.progtobi.fintrakhr.LocalDB;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.royalteck.progtobi.pos_terminal.Model.NewModal.AppType;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.CustomerDetailsModel;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.Method;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.Outlet;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.OutletGetType;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.ProductItem;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.ProductsKey;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.RegisterModel;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.TransactionsModel;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.User;

@Database(entities = {AppType.class, Method.class, Outlet.class, User.class,
        ProductItem.class, ProductsKey.class, OutletGetType.class,
        TransactionsModel.class, RegisterModel.class, CustomerDetailsModel.class}, version = 1, exportSchema = false)
public abstract class AppDatabase extends RoomDatabase {
    private static AppDatabase INSTANCE;

    public static AppDatabase getAppDatabase(Context context) {
        if (INSTANCE == null) {
            INSTANCE =
                    Room.databaseBuilder(context,
                            AppDatabase.class, "patrec_db").build();
        }
        return INSTANCE;
    }

    public abstract PatrecDAO mPatrecDAO();

    public static void destroyInstance() {
        INSTANCE = null;
    }
}
