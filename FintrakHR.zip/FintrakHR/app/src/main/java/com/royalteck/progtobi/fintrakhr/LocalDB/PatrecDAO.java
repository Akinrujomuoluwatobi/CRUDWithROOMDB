package com.royalteck.progtobi.fintrakhr.LocalDB;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.RawQuery;
import androidx.room.Update;
import androidx.sqlite.db.SupportSQLiteQuery;


import java.util.ArrayList;
import java.util.List;

@Dao
public interface PatrecDAO {

    @RawQuery()
    List<Double> findColumn(SupportSQLiteQuery query);

    @Query("Select * from apptype")
    List<AppType> fetchAppType();

    @Insert()
    void insertAllAppType(ArrayList<AppType> appTypes);

    @Insert()
    void insertProductItems(List<ProductItem> items);

    @Insert()
    void insertAllUser(List<User> users);

    @Insert()
    void insertOutlet(Outlet outlet);

    @Insert()
    void insertMethod(List<Method> methods);

    @Query("DELETE FROM apptype")
    void deleteAllAppType();

    @Query("DELETE FROM user")
    void deleteAllUsers();

    @Query("DELETE FROM outlet")
    void deleteOutlet();

    @Query("Select * from outletgettype")
    OutletGetType fetchOutletGetType();

    @Query("Select * from outlet")
    Outlet fetchOutlet();

    @Query("Select * from user where id = :uid")
    List<User> fetchUser(int uid);

    @Insert()
    void insertProductKey(List<ProductsKey> productsKey);

    @Insert()
    void insertOutletFrGetType(OutletGetType outlet);

    @Insert()
    void insertAppTypeObject(AppType appType);

    @Query("Delete From productskey")
    void deleteProductKeys();

    @Query("Delete From productitem")
    void deleteProductItems();

    @Query("Delete from OutletGetType")
    void deleteOutletAppTypeObject();

    @Query("SELECT * from productitem where revType = :type")
    List<ProductItem> fetchProducts(String type);

    @Query("SELECT * FROM productskey")
    List<ProductsKey> fetchProductKeys();

    @Insert()
    void insertAllMethod(ArrayList<Method> methods);

    @Query("SELECT * FROM method")
    List<Method> fetchMethod();

    @Insert()
    void insertTransactions(TransactionsModel transactionsModel);

    @Query("SELECT * From user Where email like :uname")
    User fetchUserUN(String uname);

    @Query("SELECT * FROM registermodel")
    RegisterModel fetchRegister();

    @Insert()
    void insertRegister(RegisterModel registerModel);

    @Query("Delete From registermodel")
    void deleteRegister();

    @Insert()
    void insertCustomer(CustomerDetailsModel customerDetails);

    @Query("Delete From transactionsmodel")
    void deleteTransaction();

    @Query("Select * from transactionsmodel Where code = :transactionCode")
    TransactionsModel fetchTransactionWithCode(String transactionCode);

    @Query("Delete From method")
    void deleteMethod();

    @Query("Select * FROM transactionsmodel WHERE sync = :b ORDER BY  id DESC")
    List<TransactionsModel> fetchTransactions(boolean b);

    @Query("Update transactionsmodel set sync = :b")
    void updateTransactions(boolean b);

    //@Query("SELECT user_pin FROM outlet  WHERE waverPassword = :s")
    //String fetchOutletWaverCode(String s);
}

