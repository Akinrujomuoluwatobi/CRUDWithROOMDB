package com.royalteck.progtobi.fintrakhr.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.ProductItem;
import com.royalteck.progtobi.pos_terminal.Model.NewModal.TransactionsModel;
import com.royalteck.progtobi.pos_terminal.ProductCheckOutActivity;
import com.royalteck.progtobi.pos_terminal.R;
import com.royalteck.progtobi.pos_terminal.RecieptGenerateActivity;

import java.util.List;

public class StaffsListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private List<TransactionsModel> items;

    private Context ctx;
    private OnItemClickListener mOnItemClickListener;


    public interface OnItemClickListener {
        void onItemClick(View view, ProductItem obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {
        this.mOnItemClickListener = mItemClickListener;
    }

    public StaffsListAdapter(Context context, List<TransactionsModel> items) {
        this.items = items;
        ctx = context;
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        public TextView name, tv_qty, price;
        public FloatingActionButton reprintBtn;


        public OriginalViewHolder(View v) {
            super(v);
            //image = v.findViewById(R.id.image);
            name = v.findViewById(R.id.name);
            price = v.findViewById(R.id.price);
            tv_qty = v.findViewById(R.id.qty);
            reprintBtn = v.findViewById(R.id.reprintBtn);
        }

    }

    @androidx.annotation.NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.trans_offline, parent, false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    // Replace the contents of a view (invoked by the layout manager)
    @Override
    public void onBindViewHolder(final RecyclerView.ViewHolder holder, final int position) {
        if (holder instanceof OriginalViewHolder) {
            final OriginalViewHolder view = (OriginalViewHolder) holder;

            final TransactionsModel p = items.get(position);
            view.tv_qty.setText(p.getCode());
            view.name.setText(p.getCustomer().get(0).getName());
            view.price.setText(p.getDate());
            view.reprintBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(ctx, RecieptGenerateActivity.class);
                    intent.putExtra("transaction", p.getCode());
                    ctx.startActivity(intent);
                }
            });
            //Tools.displayImageOriginal(ctx, view.image, p.image);

        }
    }

    @Override
    public int getItemCount() {
        return items.size();
    }


}